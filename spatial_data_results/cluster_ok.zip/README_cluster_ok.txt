README for cluster_ok Dataset

The cluster_ok file contains data from a hierarchical clustering analysis, detailing cluster assignments and silhouette scores for different levels of explained variability. The dataset includes the following fields:

seqnum: Sequential number identifying each record.
Latitud: Latitude coordinate of each hexagon.
Longitd: Longitude coordinate of each hexagon.

grps85, grps90, grps99: Cluster assignments for each hexagon, resulting from hierarchical clustering that explains 85%, 90%, and 99% of the variability, respectively. Each group represents a different level of clustering complexity based on the amount of variability explained.
sl_wd85, sl_wd90, sl_wd99: Silhouette scores for clusters resulting from hierarchical clustering that explain 85%, 90%, and 99% of the variability, respectively.The score ranges from -1 to 1 and provides an indication of how well each hexagon fits within its assigned cluster compared to other clusters.High positive values (close to 1) mean the hexagon is well clustered.
nghbr85, nghbr90, nghbr99: Neighbor clusters for each hexagon, identified through silhouette analysis. These clusters correspond to the 85%, 90%, and 99% levels of explained variability from hierarchical clustering.